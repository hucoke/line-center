﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace VNCLayout
{
    public class AlarmDataReceive
    {
        Socket SocketClientHandle = null;
        byte[] receiveByteArray=new byte[1024*1024];
        IPEndPoint ServerInfo;
        System.Timers.Timer timerCheckConnect = new System.Timers.Timer();
        bool connnected = false;
        DateTime lastReceiveTime= DateTime.MinValue;

        /// <summary>
        /// 接到的报警信息缓存区
        /// </summary>
        public Queue<string> receiveBufferString= new Queue<string>();

        public AlarmDataReceive()
        {
            
        } 

        public void Start()
        {
            ServerInfo = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 5555);
            SocketClientHandle = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            timerCheckConnect.Enabled = false;
            timerCheckConnect.Interval = 1000;
            timerCheckConnect.AutoReset = false;
            timerCheckConnect.Elapsed += TimerCheckConnect_Elapsed; 
            Connect();
            timerCheckConnect.Start();
        }

        private void TimerCheckConnect_Elapsed(object? sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                timerCheckConnect.Stop();
                if (!connnected || System.DateTime.Now.Subtract(lastReceiveTime).TotalSeconds > 10)
                {
                    Connect();
                }
            }
            catch (Exception Ex)
            {

            }
            finally
            {
                timerCheckConnect.Start();
            }
        }

        public void Connect()
        {
            try
            {
                SocketClientHandle.Connect(ServerInfo);
                SocketClientHandle.BeginReceive(receiveByteArray, 0, receiveByteArray.Length, 0, new
                                    AsyncCallback(RecieveCallBack1), SocketClientHandle);
                connnected = true;
            }
            catch (Exception ex)
            {
                connnected = false;

            }
        }

        private void RecieveCallBack1(IAsyncResult AR)
        {
            try
            {
                Socket tempSocketObj = AR.AsyncState as Socket;

                int REnd = tempSocketObj.EndReceive(AR);
                if (REnd == 0)
                {
                    return;
                } 

                string sReceiveInfo = System.Text.Encoding.UTF8.GetString(receiveByteArray, 0, REnd);

                if (sReceiveInfo.Trim() == "")
                {
                    return;
                }

                receiveBufferString.Enqueue(sReceiveInfo);

                SocketClientHandle.BeginReceive(receiveByteArray, 0, receiveByteArray.Length, 0, new
                                    AsyncCallback(RecieveCallBack1), SocketClientHandle);


                lastReceiveTime = System.DateTime.Now;

            }
            catch (Exception Ex)
            {
            }

        }



    }
}
