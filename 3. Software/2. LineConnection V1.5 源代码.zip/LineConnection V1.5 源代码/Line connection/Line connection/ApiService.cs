﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.Tasks;

namespace VNCLayout
{
    public class LoginRequest
    {
        public string username { get; set; }
        public string password { get; set; }
    }

    public class valueClass
    {
        public string token { get; set; }
        public bool logged_in { get; set; }
        // 可以根据实际返回值添加其他字段
    }

    public class LoginResponse
    {
        public int code { get; set; }
        public string message { get; set; }

        public valueClass value { get; set; }

    }

    public class RealTimeTaskRequest
    {
        public int[] device_ids { get; set; }
        public int audio_source { get; set; }
        public int volume { get; set; }

        public string capturer_id { get; set; }

        public string capturer_channel { get; set; }

        public int loop { get; set; }

        public int play_order { get; set; }
        public int interval_time { get; set; }

        public int offline { get; set; }

        public int mode { get; set; }

        public int[] file_ids { get; set; } = { 12, 11, 10, 9, 7, 6, 5, 4, 3 };
    }

    public class ApiClient
    {
        private readonly HttpClient client;
        private readonly string baseUrl;
        private string token;

        public ApiClient(string baseUrl)
        {
            this.baseUrl = baseUrl;
            this.client = new HttpClient();
        }

        public async Task Login(string username, string password)
        {
            var loginRequest = new LoginRequest
            {
                username = username,
                password = password
            };

            var url = $"{baseUrl}/v1/login";
            var json = JsonSerializer.Serialize(loginRequest);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync(url, content);
            response.Headers.Add("Authorization", "basic YWRtaW46YWRtaW5fYXBpX2tleQ==");
            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();
            var loginResponse = JsonSerializer.Deserialize<LoginResponse>(responseJson);

            token = loginResponse.value.token;

            // 设置默认请求头带上Token
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("access_token", $"{token}");
        }

        public async Task<string> StartRealTimeTask(RealTimeTaskRequest request)
        {
            if (string.IsNullOrEmpty(token))
            {
                throw new InvalidOperationException("Please login first");
            }

            var url = $"{baseUrl}/v1/real_time_task/start";

            //var json = JsonSerializer.Serialize(request, new JsonSerializerOptions
            //{
            //    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            //});

            var json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);
            response.Headers.Add("Authorization", "basic YWRtaW46YWRtaW5fYXBpX2tleQ==");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }


        public async Task<string> StopRealTimeTask(RealTimeTaskRequest request)
        {
            if (string.IsNullOrEmpty(token))
            {
                throw new InvalidOperationException("Please login first");
            }

            var url = $"{baseUrl}/v1/real_time_task/stop";
            var content = new StringContent(" ", Encoding.UTF8, "application/json");
            var response = await client.GetAsync(url);
            response.Headers.Add("Authorization", "basic YWRtaW46YWRtaW5fYXBpX2tleQ==");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }


        public async Task<string> StartTTSSpeaker(string request)
        {
            if (string.IsNullOrEmpty(token))
            {
                throw new InvalidOperationException("Please login first");
            }

            var url = $"{baseUrl}/v1/speech";

            string cententText = " {\"device_ids\": [1,2]," +
                $"\"text\": \"{request}\"," +
                "\"vcn\": \"xiaoyan\", " +
                "\"speed\": 50, " + 
                "\"volume\": 20, " + 
                "\"rdn\": \"0\"," + 
                "\"rcn\": \"1\", " + 
                "\"reg\": 0,  " + 
                " \"sync\": false,  " + 
                "\"queue\": true,  " + 
                "\"loop\": { " + 
                "\"times\": 3, \"gap\": 4 }, \"prompt\": true}";
 
            //var json = JsonSerializer.Serialize(request, new JsonSerializerOptions
            //{
            //    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            //});
            var content = new StringContent(cententText, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);
            response.Headers.Add("Authorization", "basic YWRtaW46YWRtaW5fYXBpX2tleQ==");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }


        public async Task<string> StopTTSSpeaker(int deviceId)
        {
            if (string.IsNullOrEmpty(token))
            {
                throw new InvalidOperationException("Please login first");
            }

            var url = $"{baseUrl}/v1/speech?device_ids={deviceId}"; 
            var response = await client.DeleteAsync(url);
            response.Headers.Add("Authorization", "basic YWRtaW46YWRtaW5fYXBpX2tleQ==");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }




        public class TTLStructure
        {
            public int[] device_ids { get; set; } = {1};
         

            public string vcn = "xiaoyan";

            /// <summary>
            /// 文本播放的语速，默认50，最慢 30，较慢 40，正常 50，较快 70
            /// </summary>
            public int speed = 50;

            /// <summary>
            /// 播放音量：0-100
            /// </summary>
            public int volume = 80;

            /// <summary>
            /// 合成音频数字发音，支持参数，0 数值优先, 1 完全数值, 2 完全字符串，3 字符串优先，默认值：2
            /// </summary>
            public string rdn = "0";

            /// <summary>
            /// //数字“1” 的中文发音，0：表示发音为 yao，1：表示发音为 yi，默认值：0
            /// </summary>
            public string rcn =  "1";

            /// <summary>
            /// reg 设置英文发音方式：0：自动判断处理，如果不确定将按照英文词语拼写处理（缺省）,1：所有英文按字母发音
            /// </summary>
            public int reg = 0;

            /// <summary>
            /// //true: 同步模式，语⾳播放完毕后再响应； false：即时响应（不等待播放完成）
            /// </summary>
            public bool sync = false;

            /// <summary>
            /// //true: 队列模式，如果当前有语⾳在播放，则加到队列排队播放
            /// </summary>
            public bool queue = true;


            //【注意】当 queue 为 true 时， 忽略 sync 的值（⼀律按 sync=false 来处理）
            public loopClass loop; 

            /// <summary>
            ///  //实际内容前播放前的前奏提示叮咚⾳,true 开启，false 关闭
            /// </summary>
            public bool prompt = true;

            public string text { get; set; } = "";
        }


        public class loopClass
        {

            ///【注意】loop.duration 与 loop.times 是选填字段。可只填⼀个可重复播放并限制总时⻓/次数，如果两个都填则任意⼀个条件到达都会停⽌播放。
            /// <summary>
            /// // 循环（重复）播放时⻓（秒）
            /// </summary>
            //public int duration = 600;

            /// <summary>
            ///  循环（重复）播放次数（次）
            /// </summary>
            public int times = 4;

            /// <summary>
            /// 循环（重复）播放中的间歇时间（秒）
            /// </summary>
            public int gap = 3;
        }
    }
}
