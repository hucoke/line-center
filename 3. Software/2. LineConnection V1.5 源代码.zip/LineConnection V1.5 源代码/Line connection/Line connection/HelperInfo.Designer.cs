﻿namespace VNCLayout
{
    partial class HelperInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HelperInfo));
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            richTextDescription = new RichTextBox();
            tabPage2 = new TabPage();
            pb00 = new PictureBox();
            pb02 = new PictureBox();
            pb01 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            label1 = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pb00).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb02).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb01).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(13, 69);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(573, 396);
            tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(richTextDescription);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(565, 363);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "简介";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // richTextDescription
            // 
            richTextDescription.Location = new Point(6, 6);
            richTextDescription.Name = "richTextDescription";
            richTextDescription.ReadOnly = true;
            richTextDescription.Size = new Size(553, 351);
            richTextDescription.TabIndex = 0;
            richTextDescription.Text = "版本：#Version\n\n软件由中粮可口可乐联合研创共同开发；\n\n软件引用VncSharpCore库；";
            richTextDescription.TextChanged += richTextDescription_TextChanged;
            // 
            // tabPage2
            // 
            tabPage2.AutoScroll = true;
            tabPage2.Controls.Add(pb00);
            tabPage2.Controls.Add(pb02);
            tabPage2.Controls.Add(pb01);
            tabPage2.Location = new Point(4, 26);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(565, 366);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "使用说明";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // pb00
            // 
            pb00.Image = (Image)resources.GetObject("pb00.Image");
            pb00.Location = new Point(26, 19);
            pb00.Name = "pb00";
            pb00.Size = new Size(158, 104);
            pb00.SizeMode = PictureBoxSizeMode.StretchImage;
            pb00.TabIndex = 2;
            pb00.TabStop = false;
            // 
            // pb02
            // 
            pb02.Image = (Image)resources.GetObject("pb02.Image");
            pb02.Location = new Point(162, 153);
            pb02.Name = "pb02";
            pb02.Size = new Size(240, 147);
            pb02.SizeMode = PictureBoxSizeMode.StretchImage;
            pb02.TabIndex = 1;
            pb02.TabStop = false;
            // 
            // pb01
            // 
            pb01.Image = (Image)resources.GetObject("pb01.Image");
            pb01.Location = new Point(244, 19);
            pb01.Name = "pb01";
            pb01.Size = new Size(158, 104);
            pb01.SizeMode = PictureBoxSizeMode.StretchImage;
            pb01.TabIndex = 0;
            pb01.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(332, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(262, 54);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.FromArgb(192, 192, 255);
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(17, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(309, 52);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft YaHei UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(430, 69);
            label1.Name = "label1";
            label1.Size = new Size(149, 27);
            label1.TabIndex = 5;
            label1.Text = "VncSharpCore";
            // 
            // HelperInfo
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(593, 477);
            Controls.Add(label1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(tabControl1);
            Font = new Font("Microsoft YaHei UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "HelperInfo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "集中控制助手简介";
            Load += HelperInfo_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pb00).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb02).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb01).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private RichTextBox richTextDescription;
        private PictureBox pb02;
        private PictureBox pb01;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Label label1;
        private PictureBox pb00;
    }
}