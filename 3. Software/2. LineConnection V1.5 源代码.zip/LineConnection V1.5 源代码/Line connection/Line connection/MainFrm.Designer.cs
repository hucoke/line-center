﻿namespace VNCLayout
{
    partial class MainFrm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrm));
            remoteDesktop01 = new VncSharpCore.RemoteDesktop();
            remoteDesktop03 = new VncSharpCore.RemoteDesktop();
            remoteDesktop02 = new VncSharpCore.RemoteDesktop();
            remoteDesktop04 = new VncSharpCore.RemoteDesktop();
            gpVNC04 = new GroupBox();
            gpVNC02 = new GroupBox();
            gpVNC01 = new GroupBox();
            gpVNC03 = new GroupBox();
            gpVNC05 = new GroupBox();
            remoteDesktop05 = new VncSharpCore.RemoteDesktop();
            gpVNC06 = new GroupBox();
            remoteDesktop06 = new VncSharpCore.RemoteDesktop();
            mouseRightMenu = new ContextMenuStrip(components);
            rightMenuDisConnect = new ToolStripMenuItem();
            pbLogo01 = new PictureBox();
            pbLogo02 = new PictureBox();
            pbLogo03 = new PictureBox();
            pbLogo06 = new PictureBox();
            pbLogo05 = new PictureBox();
            pbLogo04 = new PictureBox();
            timerProcessAlarm = new System.Windows.Forms.Timer(components);
            timerHoldConnect = new System.Windows.Forms.Timer(components);
            gpVNC04.SuspendLayout();
            gpVNC02.SuspendLayout();
            gpVNC01.SuspendLayout();
            gpVNC03.SuspendLayout();
            gpVNC05.SuspendLayout();
            gpVNC06.SuspendLayout();
            mouseRightMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbLogo01).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo02).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo03).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo06).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo05).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo04).BeginInit();
            SuspendLayout();
            // 
            // remoteDesktop01
            // 
            remoteDesktop01.AutoScroll = true;
            remoteDesktop01.AutoScrollMinSize = new Size(608, 427);
            remoteDesktop01.Dock = DockStyle.Fill;
            remoteDesktop01.Location = new Point(3, 19);
            remoteDesktop01.Name = "remoteDesktop01";
            remoteDesktop01.Size = new Size(296, 223);
            remoteDesktop01.TabIndex = 2;
            remoteDesktop01.Tag = "01";
            remoteDesktop01.ViewOnly = false;
            remoteDesktop01.MouseClick += remoteDesktop01_MouseClick;
            // 
            // remoteDesktop03
            // 
            remoteDesktop03.AutoScroll = true;
            remoteDesktop03.AutoScrollMinSize = new Size(608, 427);
            remoteDesktop03.Dock = DockStyle.Fill;
            remoteDesktop03.Location = new Point(3, 19);
            remoteDesktop03.Name = "remoteDesktop03";
            remoteDesktop03.Size = new Size(296, 223);
            remoteDesktop03.TabIndex = 3;
            remoteDesktop03.Tag = "03";
            remoteDesktop03.ViewOnly = false;
            remoteDesktop03.MouseClick += remoteDesktop03_MouseClick;
            // 
            // remoteDesktop02
            // 
            remoteDesktop02.AutoScroll = true;
            remoteDesktop02.AutoScrollMinSize = new Size(608, 427);
            remoteDesktop02.Dock = DockStyle.Fill;
            remoteDesktop02.Location = new Point(3, 19);
            remoteDesktop02.Name = "remoteDesktop02";
            remoteDesktop02.Size = new Size(296, 223);
            remoteDesktop02.TabIndex = 4;
            remoteDesktop02.Tag = "02";
            remoteDesktop02.ViewOnly = false;
            remoteDesktop02.MouseClick += remoteDesktop02_MouseClick;
            // 
            // remoteDesktop04
            // 
            remoteDesktop04.AutoScroll = true;
            remoteDesktop04.AutoScrollMinSize = new Size(608, 427);
            remoteDesktop04.Dock = DockStyle.Fill;
            remoteDesktop04.Location = new Point(3, 19);
            remoteDesktop04.Name = "remoteDesktop04";
            remoteDesktop04.Size = new Size(296, 223);
            remoteDesktop04.TabIndex = 4;
            remoteDesktop04.Tag = "04";
            remoteDesktop04.ViewOnly = false;
            remoteDesktop04.MouseClick += remoteDesktop04_MouseClick;
            // 
            // gpVNC04
            // 
            gpVNC04.Controls.Add(remoteDesktop04);
            gpVNC04.Location = new Point(5, 277);
            gpVNC04.Name = "gpVNC04";
            gpVNC04.Size = new Size(302, 245);
            gpVNC04.TabIndex = 5;
            gpVNC04.TabStop = false;
            gpVNC04.Text = "VNC 04";
            // 
            // gpVNC02
            // 
            gpVNC02.Controls.Add(remoteDesktop02);
            gpVNC02.Location = new Point(329, 12);
            gpVNC02.Name = "gpVNC02";
            gpVNC02.Size = new Size(302, 245);
            gpVNC02.TabIndex = 6;
            gpVNC02.TabStop = false;
            gpVNC02.Text = "VNC 02";
            // 
            // gpVNC01
            // 
            gpVNC01.Controls.Add(remoteDesktop01);
            gpVNC01.Location = new Point(5, 12);
            gpVNC01.Name = "gpVNC01";
            gpVNC01.Size = new Size(302, 245);
            gpVNC01.TabIndex = 7;
            gpVNC01.TabStop = false;
            gpVNC01.Text = "VNC 01";
            // 
            // gpVNC03
            // 
            gpVNC03.Controls.Add(remoteDesktop03);
            gpVNC03.Location = new Point(652, 12);
            gpVNC03.Name = "gpVNC03";
            gpVNC03.Size = new Size(302, 245);
            gpVNC03.TabIndex = 8;
            gpVNC03.TabStop = false;
            gpVNC03.Text = "VNC 03";
            // 
            // gpVNC05
            // 
            gpVNC05.Controls.Add(remoteDesktop05);
            gpVNC05.Location = new Point(326, 277);
            gpVNC05.Name = "gpVNC05";
            gpVNC05.Size = new Size(302, 245);
            gpVNC05.TabIndex = 10;
            gpVNC05.TabStop = false;
            gpVNC05.Text = "VNC 05";
            // 
            // remoteDesktop05
            // 
            remoteDesktop05.AutoScroll = true;
            remoteDesktop05.AutoScrollMinSize = new Size(608, 427);
            remoteDesktop05.Dock = DockStyle.Fill;
            remoteDesktop05.Location = new Point(3, 19);
            remoteDesktop05.Name = "remoteDesktop05";
            remoteDesktop05.Size = new Size(296, 223);
            remoteDesktop05.TabIndex = 4;
            remoteDesktop05.Tag = "05";
            remoteDesktop05.ViewOnly = false;
            remoteDesktop05.MouseClick += remoteDesktop05_MouseClick;
            // 
            // gpVNC06
            // 
            gpVNC06.Controls.Add(remoteDesktop06);
            gpVNC06.Location = new Point(649, 274);
            gpVNC06.Name = "gpVNC06";
            gpVNC06.Size = new Size(302, 245);
            gpVNC06.TabIndex = 6;
            gpVNC06.TabStop = false;
            gpVNC06.Text = "VNC 06";
            // 
            // remoteDesktop06
            // 
            remoteDesktop06.AutoScroll = true;
            remoteDesktop06.AutoScrollMinSize = new Size(608, 427);
            remoteDesktop06.Dock = DockStyle.Fill;
            remoteDesktop06.Location = new Point(3, 19);
            remoteDesktop06.Name = "remoteDesktop06";
            remoteDesktop06.Size = new Size(296, 223);
            remoteDesktop06.TabIndex = 4;
            remoteDesktop06.Tag = "06";
            remoteDesktop06.ViewOnly = false;
            remoteDesktop06.MouseClick += remoteDesktop06_MouseClick;
            // 
            // mouseRightMenu
            // 
            mouseRightMenu.Items.AddRange(new ToolStripItem[] { rightMenuDisConnect });
            mouseRightMenu.Name = "mouseRightMenu";
            mouseRightMenu.RenderMode = ToolStripRenderMode.Professional;
            mouseRightMenu.Size = new Size(125, 26);
            // 
            // rightMenuDisConnect
            // 
            rightMenuDisConnect.Name = "rightMenuDisConnect";
            rightMenuDisConnect.Size = new Size(124, 22);
            rightMenuDisConnect.Text = "断开连接";
            rightMenuDisConnect.Click += rightMenuDisConnect_Click;
            // 
            // pbLogo01
            // 
            pbLogo01.Image = Properties.Resources.cocacola02;
            pbLogo01.Location = new Point(984, 73);
            pbLogo01.Name = "pbLogo01";
            pbLogo01.Size = new Size(105, 35);
            pbLogo01.SizeMode = PictureBoxSizeMode.StretchImage;
            pbLogo01.TabIndex = 11;
            pbLogo01.TabStop = false;
            pbLogo01.Visible = false;
            // 
            // pbLogo02
            // 
            pbLogo02.Image = Properties.Resources.cocacola02;
            pbLogo02.Location = new Point(984, 109);
            pbLogo02.Name = "pbLogo02";
            pbLogo02.Size = new Size(105, 35);
            pbLogo02.SizeMode = PictureBoxSizeMode.StretchImage;
            pbLogo02.TabIndex = 12;
            pbLogo02.TabStop = false;
            pbLogo02.Visible = false;
            // 
            // pbLogo03
            // 
            pbLogo03.Image = Properties.Resources.cocacola02;
            pbLogo03.Location = new Point(984, 144);
            pbLogo03.Name = "pbLogo03";
            pbLogo03.Size = new Size(105, 35);
            pbLogo03.SizeMode = PictureBoxSizeMode.StretchImage;
            pbLogo03.TabIndex = 13;
            pbLogo03.TabStop = false;
            pbLogo03.Visible = false;
            // 
            // pbLogo06
            // 
            pbLogo06.Image = Properties.Resources.cocacola02;
            pbLogo06.Location = new Point(984, 242);
            pbLogo06.Name = "pbLogo06";
            pbLogo06.Size = new Size(105, 35);
            pbLogo06.SizeMode = PictureBoxSizeMode.StretchImage;
            pbLogo06.TabIndex = 16;
            pbLogo06.TabStop = false;
            pbLogo06.Visible = false;
            // 
            // pbLogo05
            // 
            pbLogo05.Image = Properties.Resources.cocacola02;
            pbLogo05.Location = new Point(984, 212);
            pbLogo05.Name = "pbLogo05";
            pbLogo05.Size = new Size(105, 35);
            pbLogo05.SizeMode = PictureBoxSizeMode.StretchImage;
            pbLogo05.TabIndex = 15;
            pbLogo05.TabStop = false;
            pbLogo05.Visible = false;
            // 
            // pbLogo04
            // 
            pbLogo04.Image = Properties.Resources.cocacola02;
            pbLogo04.Location = new Point(984, 176);
            pbLogo04.Name = "pbLogo04";
            pbLogo04.Size = new Size(105, 35);
            pbLogo04.SizeMode = PictureBoxSizeMode.StretchImage;
            pbLogo04.TabIndex = 14;
            pbLogo04.TabStop = false;
            pbLogo04.Visible = false;
            // 
            // timerProcessAlarm
            // 
            timerProcessAlarm.Tick += timerProcessAlarm_Tick;
            // 
            // MainFrm
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(1106, 754);
            Controls.Add(pbLogo06);
            Controls.Add(pbLogo05);
            Controls.Add(pbLogo04);
            Controls.Add(pbLogo03);
            Controls.Add(pbLogo02);
            Controls.Add(pbLogo01);
            Controls.Add(gpVNC06);
            Controls.Add(gpVNC05);
            Controls.Add(gpVNC03);
            Controls.Add(gpVNC01);
            Controls.Add(gpVNC02);
            Controls.Add(gpVNC04);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "MainFrm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "集中控制助手";
            WindowState = FormWindowState.Maximized;
            FormClosing += MainFrm_FormClosing;
            Load += MainFrm_Load;
            MouseDown += MainFrm_MouseDown;
            MouseLeave += MainFrm_MouseLeave;
            MouseHover += MainFrm_MouseHover;
            MouseMove += MainFrm_MouseMove;
            MouseUp += MainFrm_MouseUp;
            Resize += MainFrm_Resize;
            gpVNC04.ResumeLayout(false);
            gpVNC02.ResumeLayout(false);
            gpVNC01.ResumeLayout(false);
            gpVNC03.ResumeLayout(false);
            gpVNC05.ResumeLayout(false);
            gpVNC06.ResumeLayout(false);
            mouseRightMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pbLogo01).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo02).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo03).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo06).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo05).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbLogo04).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private VncSharpCore.RemoteDesktop remoteDesktop01;
        private VncSharpCore.RemoteDesktop remoteDesktop03;
        private VncSharpCore.RemoteDesktop remoteDesktop02;
        private VncSharpCore.RemoteDesktop remoteDesktop04;
        private GroupBox gpVNC04;
        private GroupBox gpVNC02;
        private GroupBox gpVNC01;
        private GroupBox gpVNC03;
        private GroupBox gpVNC05;
        private VncSharpCore.RemoteDesktop remoteDesktop05;
        private GroupBox gpVNC06;
        private VncSharpCore.RemoteDesktop remoteDesktop06;
        private ContextMenuStrip mouseRightMenu;
        private ToolStripMenuItem rightMenuDisConnect;
        private PictureBox pbLogo01;
        private PictureBox pbLogo02;
        private PictureBox pbLogo03;
        private PictureBox pbLogo06;
        private PictureBox pbLogo05;
        private PictureBox pbLogo04;
        private System.Windows.Forms.Timer timerProcessAlarm;
        private System.Windows.Forms.Timer timerHoldConnect;
    }
}