﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VNCLayout
{
    public partial class HelperInfo : Form
    {
        public HelperInfo()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void HelperInfo_Load(object sender, EventArgs e)
        {
            pb00.Height = 500;
            pb01.Height = 500;
            pb02.Height = 500;
            pb00.Top = 5;
            pb00.Left = 5;

            pb00.Width = tabControl1.Width - 30;
            pb01.Width = pb00.Width;
            pb02.Width = pb01.Width;

            pb01.Left = pb00.Left;
            pb01.Top = pb00.Top + pb00.Height + 20;

            pb02.Left = pb00.Left;
            pb02.Top = pb01.Top + pb01.Height + 20;

            var version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version; 
            richTextDescription.Text = richTextDescription.Text.Replace("#Version", version.ToString());
        }

        private void richTextDescription_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
