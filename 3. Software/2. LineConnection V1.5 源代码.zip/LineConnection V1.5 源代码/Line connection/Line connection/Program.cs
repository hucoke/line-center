namespace VNCLayout
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            Application.ThreadException += Application_ThreadException; ;
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);  
            ApplicationConfiguration.Initialize(); 
            Application.Run(new MainFrm());
        }

        private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            //1��¼��־��Ϣ
            Exception ex = e.Exception;
            //2 ������ʾ
            MessageBox.Show(string.Format("Application_ThreadException����δ�����쳣��{0}\r\n�쳣��Ϣ��{1}\r\n�쳣��ջ��{2}", ex.GetType(), ex.Message, ex.StackTrace)); 
        }
    }
}