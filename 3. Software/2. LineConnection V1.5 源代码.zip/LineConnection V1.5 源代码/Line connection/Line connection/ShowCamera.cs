﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibVLCSharp.Shared;
using LibVLCSharp.WinForms;

namespace VNCLayout
{
 
    public partial class ShowCamera : Form
    {
        private LibVLC? _libVLC;
        private MediaPlayer? _mediaPlayer;
        private Media? _media;

        public ShowCamera()
        {
            InitializeComponent();
            InitializePlayer();
        }


        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            // 创建视频显示控件
            var videoView = new VideoView
            {
                Dock = DockStyle.Fill,
                MediaPlayer = _mediaPlayer
            };

            Controls.Add(videoView);

            // 开始播放RTSP流
            StartStreaming();
        }


        private void StartStreaming()
        {
            try
            {
                string rtspUrl = "rtsp://admin:wraith998@192.168.18.13:554/h264/ch1/main/av_stream"; // 替换为实际的RTSP地址

                _media = new Media(_libVLC, new Uri(rtspUrl));
                _mediaPlayer?.Play(_media);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error starting stream: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void InitializePlayer()
        {
            // 初始化VLC组件
            Core.Initialize();

            _libVLC = new LibVLC();
            _mediaPlayer = new MediaPlayer(_libVLC);
        }


        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);

            // 清理资源
            StopStreaming();
            _mediaPlayer?.Dispose();
            _libVLC?.Dispose();
        }


        private void StopStreaming()
        {
            _mediaPlayer?.Stop();
            _media?.Dispose();
            _media = null; 
        }

    }



}
