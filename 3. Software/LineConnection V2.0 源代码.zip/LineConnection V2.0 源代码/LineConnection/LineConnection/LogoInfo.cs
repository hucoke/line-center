﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VNCLayout
{
    public class LogoInfo
    {
        public PictureBox pbLogo;
        public string clientCode = "";
        public string remoteObjName = "";

        public LogoInfo(PictureBox pbLogo01)
        {
            this.pbLogo = pbLogo01; 
        }
    }
}
