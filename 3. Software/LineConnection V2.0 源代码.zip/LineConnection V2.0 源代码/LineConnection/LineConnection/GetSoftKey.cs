﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace VNCLayout
{
    public class GetSoftKey
    {

        public GetSoftKey() { }

        public string GetKey(string macString)
        {
            if (macString.Trim() == "")
            {
                return "((((!!!@@#&&$JJFNSALNNDLLLQDJDAKD!!@#$$#@#@#";
            }
            string[] Keys = new string[] {
                    "AAA%@@$!@D!$@#@V*((A*&N((A*&N(YTGHJKL:YRDGA%@@$!@YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>AAAAAAAs(A*&N(YTGHJKL:YRDGA%@@$!@s11egn4eA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>CVBLIO*IJLM<?:}{:>M<NHYTUOJM>dx1$%$#@!$5za6A%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>",
                    "A%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>FCVBLIO*IJLMA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM><?:}{:>(A*&N(YTGHJKL:YRDGA%@@$!@M<NHY#@V*((A*&N(YTG(A*&NTUOJM>",
                    "3******#@!)@$*A%@@$!@D!$@#@V*((A*&N((A*&N(YTGHJKL:#@V*((A*&N(YTG(A*&N%@@$!@YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NH(A*&N(YTGHJKL:YRDGA%@@$!@YTUOJM>$(*$#(*@!@)!(@)A%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>(#@*$@(@!)@(#)*@$*#$(#*#)@(!)@(#@)#()@(!@",
                    "((((!!!@@#A%@@$!@D!$@#@V*((A*&N(YTG(A*&N(YTGHJKL:Y#@V*((A*&N(YTG(A*&NRDGA%@@$!@HJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>&&$JJFNSALNA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>NDLLLQDJDAKD!!@#(A*&N(YTGHJKL:YRDGA%@@$!@$$#@#@#",
                    ")(DMAQA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDG#@V*((A*&N(YTG(A*&NFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>NNNKKKKKA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>SSSLSLLSIEA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>W#@*$*&%&#$#JKjzV<SEWV",
                    "A!@#$A%@@$!@D!$@#@V*((A*&N(YTGHJK#@V*((A*&N(YTG(A*&NL:YRD(A*&N(YTGHJKL:YRDGA%@@$!@GFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>#$(A*&N(YTGHJKL:YRDGA%@@$!@NNN(UA%@@$!@D!$@#@V*((A*&N(YTGHJKL:YRDGFCVBLIO*IJLM<?:}{:>M<NHYTUOJM>JFJ^#*$KFM@K$M#Y@^DDSXMXWIMDI#RIDkLDIDydufsico,we098jdmj1k3dsd3"
            };
            string formated = macString.Replace("1", "AAA").Replace("D", "DDD").Replace("-", "VACH");
            byte[] frontBytes;
            byte[] endBytes;
            switch (formated.Substring(0, 1).ToLower())
            {
                case "1": 
                case "a":
                case "3":
                case "2":
                    frontBytes = Encoding.UTF8.GetBytes(Keys[0]);
                    break;

                case "5":
                case "6":
                case "7":
                case "8":
                case "t":
                    frontBytes = Encoding.UTF8.GetBytes(Keys[1]);
                    break;

                case "s":
                case "d":
                case "e":
                case "g":
                case "o":
                    frontBytes = Encoding.UTF8.GetBytes(Keys[2]);
                    break;

                default:
                    frontBytes = Encoding.UTF8.GetBytes(Keys[3]);
                    break;
            }

            switch (formated.Substring(4, 1).ToLower())
            {
                case "1":
                case "a":
                case "3":
                case "2":
                    endBytes = Encoding.UTF8.GetBytes(Keys[4]);
                    break;
                default:
                    endBytes = Encoding.UTF8.GetBytes(Keys[5]);
                    break;
            }

            byte[] bytes = Encoding.UTF8.GetBytes(formated);  
            MD5 md5 = MD5.Create();
            var result = md5.ComputeHash(bytes);
            var result2 = md5.ComputeHash(endBytes);
            var result3= md5.ComputeHash(frontBytes);
            StringBuilder sbstring = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                sbstring.Append(result[i].ToString("X2"));
            }
            for (int i = 0; i < result2.Length; i++)
            {
                sbstring.Append(result2[i].ToString("X2"));
            }
            for (int i = 0; i < result3.Length; i++)
            {
                sbstring.Append(result3[i].ToString("X2"));
            }

            return sbstring.ToString();  
        }
    }
}
