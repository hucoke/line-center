using Microsoft.VisualBasic.Devices;
using System;
using System.Diagnostics.Metrics;
using System.Net.NetworkInformation;
using System.Speech.Synthesis;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml;
using VncSharpCore;

namespace VNCLayout
{
    public partial class MainFrm : Form
    {
        Point mPoint;

        bool closeFrm = false;

        GetSoftKey getSoftKey = new GetSoftKey();

        string key = "NoKeys";

        List<LogoInfo> logoInfos = new List<LogoInfo>();


        AlarmDataReceive alarmInfo = new AlarmDataReceive();

        string alarmRemeberString = "";

        /// <summary>
        /// 1: 2�����ڣ����Ҳ��֣�
        /// 2��2�����ڣ����沼�֣�
        /// 3��3�����ڣ���1��2��
        /// 4��4�����ڣ�ƽ������
        /// </summary>
        private int currentLayoutCode = 1;

        /// <summary>
        /// ��ǰ�Ҽ��˵�������VNC���Ӷ���
        /// </summary>
        RemoteDesktop operatorDeskObj = null;

        /// <summary>
        /// �ͻ���������Ϣ����
        /// </summary>
        List<clientInfo> clientInfos = new List<clientInfo>();

        bool stopFrmSize = false;
        public MainFrm()
        {
            InitializeComponent();
            loadSetting();

        }


        private void MainFrm_Load(object sender, EventArgs e)
        {
            closeFrm = false;

            logoInfos.Add(new LogoInfo(pbLogo01));
            logoInfos.Add(new LogoInfo(pbLogo02));
            logoInfos.Add(new LogoInfo(pbLogo03));
            logoInfos.Add(new LogoInfo(pbLogo04));
            logoInfos.Add(new LogoInfo(pbLogo05));
            logoInfos.Add(new LogoInfo(pbLogo06));

            alarmInfo.Start();

            timerProcessAlarm.Start();


        }

        private bool ConfirmSoftKey()
        {
            List<string> listMac = new List<string>();
            foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                string mac = GetMacAddress(nic);
                listMac.Add(mac);
                if (getSoftKey.GetKey(mac) == key)
                    return true;
            }

            return false;
        }

        private static string GetMacAddress(NetworkInterface nic)
        {
            byte[] bytes = nic.GetPhysicalAddress().GetAddressBytes();
            string macAddress = BitConverter.ToString(bytes).Replace("-", "");
            return macAddress;
        }

        private async void ConnectVncServer(RemoteDesktop rdObj, clientInfo clientObj)
        {
            try
            {
                //if (!ConfirmSoftKey())
                //{
                //    MessageBox.Show("����û�б���Ȩʹ�ã�����������Settings.xml�ļ��ڵ�Key�ڵ�����Ȩ����!!!");
                //    return;
                //}

                if (rdObj.Parent == null)
                {
                    return;
                }

                if (!rdObj.Parent.Visible)
                {
                    if (rdObj.IsConnected)
                    {
                        rdObj.Disconnect();
                    }
                    return;
                }

                rdObj.ConnectComplete -= RdObj_ConnectComplete;
                rdObj.ConnectionLost -= RdObj_ConnectionLost;

                rdObj.ConnectComplete += RdObj_ConnectComplete;
                rdObj.ConnectionLost += RdObj_ConnectionLost;

                rdObj.VncPort = clientObj.port;

                rdObj.vncPassword = clientObj.vncPassword;


                clientObj.isManualDisconnect = false;
                rdObj.Tag = clientObj.SerialNo;
                rdObj.Parent.Tag = clientObj.SerialNo;
                rdObj.Parent.Text = $"{clientObj.name} {clientObj.ipAddress}";

                await rdObj.Connect(clientObj.ipAddress, false, true);
                if (rdObj.IsConnected)
                {
                    rdObj.FullScreenUpdate();

                    rdObj.Update();

                    rdObj.Show();
                }
                else
                {
                    throw new Exception($"����ʧ�ܣ�{rdObj.Tag.ToString()}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"����IP��{clientObj.ipAddress} ʧ�ܣ���ȷ��Ŀ�������Ƿ��п���VNC����������������Ƿ���ȷ��ϵͳ������Ϣ��{ex.Message}");
                return;
            }

        }

        private void RdObj_ConnectionLost(object? sender, EventArgs e)
        {
            try
            {
                this.Invoke(() => {
                    RemoteDesktop remoteObj = (RemoteDesktop)sender;
                    var clientObj = clientInfos.Find(x => x.SerialNo.Equals(remoteObj.Tag.ToString()));
                    if (clientObj == null || clientObj.isManualDisconnect || operatorDeskObj.holdStop)
                    {
                        return;
                    }
                    else
                    {
                        ConnectVncServer(remoteObj, clientObj);
                    }
                });

            }
            catch (Exception Ex)
            {
                MessageBox.Show($"������������ʱ�������쳣���쳣ԭ��{Ex.Message}");
                return;
            }
        }

        private void RdObj_ConnectComplete(object sender, ConnectEventArgs e)
        {


        }

        private void SpeakerOut(string info)
        {
            try
            {
                using (var speechSyn = new SpeechSynthesizer())
                {
                    speechSyn.Volume = 50;// ����������С
                    speechSyn.Rate = 0; // �����ٶȱ仯ֵ 
                    speechSyn.Speak(info);
                }
            }
            catch (System.PlatformNotSupportedException ex1)
            {

            }
            catch (Exception ex2)
            {

            }
        }

        private void loadSetting()
        {
            XmlDocument xdoc = new XmlDocument();
            try
            {
                xdoc.Load(Application.StartupPath + "\\Settings.xml");
                XmlElement Xmlroot = null, theMainNode = null;
                Xmlroot = xdoc.DocumentElement;

                theMainNode = (XmlElement)Xmlroot.SelectSingleNode("/root/baseInfo");

                currentLayoutCode = Convert.ToInt32(theMainNode.GetElementsByTagName("layout").Item(0).InnerText.Trim());


                theMainNode = (XmlElement)Xmlroot.SelectSingleNode("/root/client");
                mouseRightMenu.Items.Add(new ToolStripSeparator());
                foreach (XmlElement xmlElement in theMainNode.ChildNodes)
                {
                    clientInfo clientObj = new clientInfo();
                    clientObj.name = xmlElement.GetAttribute("name").Trim();
                    clientObj.ipAddress = xmlElement.GetAttribute("ip").Trim();
                    clientObj.port = Convert.ToInt32(xmlElement.GetAttribute("port"));
                    clientObj.vncPassword = xmlElement.GetAttribute("password").Trim();
                    clientObj.clientNo = xmlElement.GetAttribute("code").Trim();
                    clientObj.LineName = xmlElement.GetAttribute("LineName").Trim();
                    clientObj.SerialNo = xmlElement.GetAttribute("SerialNO").ToLower().Trim();
                    clientInfos.Add(clientObj);
                }

                var groupInfo = clientInfos.GroupBy(x => x.LineName);
                foreach (var group in groupInfo)
                {
                    var SubMenuItemNode = mouseRightMenu.Items.Add(group.Key) as ToolStripMenuItem;

                    group.ToList<clientInfo>().ForEach(
                        x =>
                        {
                            ToolStripItem newItemObj = SubMenuItemNode.DropDownItems.Add(x.name);
                            newItemObj.Tag = x.SerialNo;
                            newItemObj.ToolTipText = x.SerialNo;
                            newItemObj.Click += NewItemObj_Click;
                        }
                        );
                }

                theMainNode = (XmlElement)Xmlroot.SelectSingleNode("/root");
                key = theMainNode.GetElementsByTagName("key").Item(0).InnerText.Trim();

                mouseRightMenu.Items.Add(new ToolStripSeparator());
                var layoutReset = mouseRightMenu.Items.Add("���ڲ���") as ToolStripMenuItem;
                var threeLayout = layoutReset.DropDownItems.Add("3������(��1��2)");
                threeLayout.Click += ThreeLayout_Click;
                var sixLayout = layoutReset.DropDownItems.Add("6������(��3��3)");
                sixLayout.Click += SixLayout_Click;

                mouseRightMenu.Items.Add(new ToolStripSeparator());

                var closeMenuItemObj = mouseRightMenu.Items.Add("�˳�");
                closeMenuItemObj.Click += CloseMenuItemObj_Click;

                var helpInfo = mouseRightMenu.Items.Add("����");
                helpInfo.Click += HelpInfo_Click;

            }
            catch (Exception Ex)
            {
                MessageBox.Show("�����ļ�Settings.xml�����쳣���޷�������ȡ���������޸ĺ��ٴγ�������������");
            }
            finally
            {
                xdoc = null;
            }


        }

        private void SixLayout_Click(object? sender, EventArgs e)
        {
            closeFrm = true;
            ConfirmAllFrmIsDisconnect();
            currentLayoutCode = 6;
            ResizeAllItem();
        }

        private void ThreeLayout_Click(object? sender, EventArgs e)
        {
            closeFrm = true;
            ConfirmAllFrmIsDisconnect();
            currentLayoutCode = 3;
            ResizeAllItem();
        }

        private void ConfirmAllFrmIsDisconnect()
        {
            if (remoteDesktop01.IsConnected)
            {
                remoteDesktop01.Tag = "";
                remoteDesktop01.Parent.BackColor = Color.Transparent;
                remoteDesktop01.Parent.Padding = new Padding(0, 0, 0, 0);
                remoteDesktop01.Disconnect();
            }

            if (remoteDesktop02.IsConnected)
            {
                remoteDesktop02.Tag = "";
                remoteDesktop02.Parent.BackColor = Color.Transparent;
                remoteDesktop02.Parent.Padding = new Padding(0, 0, 0, 0);
                remoteDesktop02.Disconnect();
            }

            if (remoteDesktop03.IsConnected)
            {
                remoteDesktop03.Tag = "";
                remoteDesktop03.Parent.BackColor = Color.Transparent;
                remoteDesktop03.Parent.Padding = new Padding(0, 0, 0, 0);
                remoteDesktop03.Disconnect();
            }

            if (remoteDesktop04.IsConnected)
            {
                remoteDesktop04.Tag = "";
                remoteDesktop04.Parent.BackColor = Color.Transparent;
                remoteDesktop04.Parent.Padding = new Padding(0, 0, 0, 0);
                remoteDesktop04.Disconnect();
            }

            if (remoteDesktop05.IsConnected)
            {
                remoteDesktop05.Tag = "";
                remoteDesktop05.Parent.BackColor = Color.Transparent;
                remoteDesktop05.Parent.Padding = new Padding(0, 0, 0, 0);
                remoteDesktop05.Disconnect();
            }

            if (remoteDesktop06.IsConnected)
            {
                remoteDesktop06.Tag = "";
                remoteDesktop06.Parent.BackColor = Color.Transparent;
                remoteDesktop06.Parent.Padding = new Padding(0, 0, 0, 0);
                remoteDesktop06.Disconnect();
            }

            logoInfos.ForEach(x => x.pbLogo.Visible = false);
        }

        private void HelpInfo_Click(object? sender, EventArgs e)
        {
            HelperInfo infoFrm = new HelperInfo();
            infoFrm.ShowDialog();
        }

        private void CloseMenuItemObj_Click(object? sender, EventArgs e)
        {
            if (MessageBox.Show("�Ƿ������Ҫ�ر�������", "�����ر�ȷ��", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }
            else
            {
                this.Close();
            }
        }

        private void NewItemObj_Click(object? sender, EventArgs e)
        {
            try
            {
                ToolStripItem toolStripItem = (ToolStripItem)sender;
                if (operatorDeskObj.IsConnected)
                {
                    var clientObj = clientInfos.Find(x => x.SerialNo.Equals(operatorDeskObj.Tag.ToString()));
                    if (clientObj != null)
                    {
                        clientObj.isManualDisconnect = true;
                        operatorDeskObj.holdStop = true;
                    }
                    operatorDeskObj.Disconnect();
                }
                ConnectVncServer(operatorDeskObj, clientInfos.Find(x => x.SerialNo.Equals(toolStripItem.Tag.ToString())));
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }

        private void MainFrm_FormClosing(object sender, FormClosingEventArgs e)
        {
            closeFrm = true;
        }

        private int GetHeight(int width)
        {
            return (int)(width * 0.75);
        }

        private void ResizeAllItem()
        {
            int widthSpace = 10;
            int heightSpace = 10;
            switch (currentLayoutCode)
            {
                case 1:
                    gpVNC01.Top = 5;
                    gpVNC01.Left = 5;
                    gpVNC01.Width = this.Width - 30;
                    gpVNC01.Height = this.Height - 50;

                    gpVNC01.Visible = true;
                    gpVNC02.Visible = false;
                    gpVNC03.Visible = false;
                    gpVNC04.Visible = false;
                    gpVNC05.Visible = false;
                    gpVNC06.Visible = false;

                    break;

                case 3:
                    int calHeigh2 = (this.Height) / 2 - heightSpace;
                    int calWidth2 = this.Width / 3 - widthSpace;
                    gpVNC01.Top = 5;
                    gpVNC01.Left = 5;
                    gpVNC01.Width = this.Width - calWidth2 - widthSpace * 2;
                    gpVNC01.Height = this.Height - heightSpace;

                    int spaceHeight = gpVNC01.Height - (calHeigh2 * 2);

                    gpVNC02.Top = 5;
                    gpVNC02.Left = gpVNC01.Left + gpVNC01.Width + widthSpace;
                    gpVNC02.Width = calWidth2;
                    gpVNC02.Height = calHeigh2;

                    gpVNC03.Top = gpVNC02.Top + gpVNC02.Height + heightSpace;
                    gpVNC03.Left = gpVNC02.Left;
                    gpVNC03.Width = gpVNC02.Width;
                    gpVNC03.Height = gpVNC02.Height;

                    gpVNC01.Visible = true;
                    gpVNC02.Visible = true;
                    gpVNC03.Visible = true;

                    gpVNC04.Visible = false;
                    gpVNC05.Visible = false;
                    gpVNC06.Visible = false;


                    break;

                case 4:
                    int calWidth3 = this.Width / 2 - widthSpace;
                    int calHeigh3 = this.Height / 2 - heightSpace;

                    gpVNC01.Top = 5;
                    gpVNC01.Left = 5;
                    gpVNC01.Width = calWidth3;
                    gpVNC01.Height = calHeigh3;

                    gpVNC02.Top = 5;
                    gpVNC02.Left = gpVNC01.Left + gpVNC01.Width + 10;
                    gpVNC02.Width = calWidth3;
                    gpVNC02.Height = calHeigh3;


                    gpVNC03.Top = gpVNC01.Top + gpVNC01.Height + 10;
                    gpVNC03.Left = gpVNC01.Left;
                    gpVNC03.Width = calWidth3;
                    gpVNC03.Height = calHeigh3;

                    gpVNC04.Width = calWidth3;
                    gpVNC04.Height = calHeigh3;
                    gpVNC04.Top = gpVNC02.Top + gpVNC02.Height + 10;
                    gpVNC04.Left = gpVNC02.Left;


                    gpVNC01.Visible = true;
                    gpVNC02.Visible = true;
                    gpVNC03.Visible = true;
                    gpVNC04.Visible = true;
                    gpVNC05.Visible = false;
                    gpVNC06.Visible = false;


                    break;

                default:

                    int calWidth6 = this.Width / 3 - widthSpace;
                    int calHeigh6 = this.Height / 2 - heightSpace;

                    gpVNC01.Top = 5;
                    gpVNC01.Left = 5;
                    gpVNC01.Width = calWidth6;
                    gpVNC01.Height = calHeigh6;

                    gpVNC02.Top = gpVNC01.Top;
                    gpVNC02.Left = gpVNC01.Left + gpVNC01.Width + widthSpace;
                    gpVNC02.Width = calWidth6;
                    gpVNC02.Height = calHeigh6;

                    gpVNC03.Top = gpVNC01.Top;
                    gpVNC03.Left = gpVNC02.Left + gpVNC02.Width + widthSpace;
                    gpVNC03.Width = calWidth6;
                    gpVNC03.Height = calHeigh6;

                    gpVNC04.Top = gpVNC01.Top + gpVNC01.Height + widthSpace;
                    gpVNC04.Left = gpVNC01.Left;
                    gpVNC04.Width = calWidth6;
                    gpVNC04.Height = calHeigh6;

                    gpVNC05.Top = gpVNC04.Top;
                    gpVNC05.Left = gpVNC02.Left;
                    gpVNC05.Width = calWidth6;
                    gpVNC05.Height = calHeigh6;

                    gpVNC06.Top = gpVNC04.Top;
                    gpVNC06.Left = gpVNC03.Left;
                    gpVNC06.Width = calWidth6;
                    gpVNC06.Height = calHeigh6;

                    gpVNC01.Visible = true;
                    gpVNC02.Visible = true;
                    gpVNC03.Visible = true;
                    gpVNC04.Visible = true;
                    gpVNC05.Visible = true;
                    gpVNC06.Visible = true;

                    break;
            }

        }

        private void MainFrm_Resize(object sender, EventArgs e)
        {
            if (stopFrmSize)
                return;

            ResizeAllItem();

        }

        private void remoteDesktop01_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
            {
                return;
            }

            ShowConfirmFrm(sender, e);
        }

        private void ShowConfirmFrm(object sender, MouseEventArgs e)
        {
            operatorDeskObj = (RemoteDesktop)sender;
            mouseRightMenu.Tag = operatorDeskObj.Tag.ToString();
            ShowContextMenu((GroupBox)operatorDeskObj.Parent);
            if (operatorDeskObj.IsConnected)
            {
                mouseRightMenu.Items[0].Enabled = true;
                mouseRightMenu.Items[1].Enabled = false;

            }
            else
            {
                var findResult = logoInfos.Find(x => x.clientCode == operatorDeskObj.Tag.ToString() && x.remoteObjName.Equals(operatorDeskObj.Name));
                if (findResult != null)
                {
                    findResult.clientCode = "";
                    findResult.pbLogo.Visible = false;
                    findResult.remoteObjName = "";
                }
                mouseRightMenu.Items[0].Enabled = false;
                mouseRightMenu.Items[1].Enabled = true;
            }
        }

        private void ShowContextMenu(GroupBox gbObj)
        {
            mouseRightMenu.Show(gbObj, new Point(5, 20));
        }

        private void remoteDesktop02_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
            {
                return;
            }

            ShowConfirmFrm(sender, e);
        }

        private void remoteDesktop03_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
            {
                return;
            }

            ShowConfirmFrm(sender, e);
        }

        private void remoteDesktop04_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
            {
                return;
            }

            ShowConfirmFrm(sender, e);
        }

        private void rightMenuDisConnect_Click(object sender, EventArgs e)
        {
            if (operatorDeskObj != null && operatorDeskObj.IsConnected)
            {
                var clientObj = clientInfos.Find(x => x.SerialNo.Equals(operatorDeskObj.Tag.ToString()));
                if (clientObj != null)
                {
                    clientObj.isManualDisconnect = true;
                } 
                operatorDeskObj.holdStop = true;
                operatorDeskObj.Disconnect();
                var findResult = logoInfos.Find(x => x.clientCode == operatorDeskObj.Tag.ToString() &&
                                                                    x.remoteObjName.Equals(operatorDeskObj.Name));
                if (findResult != null)
                {
                    findResult.clientCode = "";
                    findResult.pbLogo.Visible = false;
                    findResult.remoteObjName = "";
                }
                operatorDeskObj.Tag = "";
                operatorDeskObj.Parent.Tag = "";
                operatorDeskObj.Parent.Text = "";
                operatorDeskObj.Parent.BackColor = Color.Transparent;
                operatorDeskObj.Parent.Padding = new Padding(0, 0, 0, 0);
            }
        }

        private void remoteDesktop05_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
            {
                return;
            }

            ShowConfirmFrm(sender, e);
        }

        private void remoteDesktop06_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
            {
                return;
            }

            ShowConfirmFrm(sender, e);
        }

        private void MainFrm_MouseDown(object sender, MouseEventArgs e)
        {
            mPoint = new Point(e.X, e.Y);
            this.WindowState = FormWindowState.Normal;
        }

        private void MainFrm_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + e.X - mPoint.X, this.Location.Y + e.Y - mPoint.Y);
            }
        }

        private void MainFrm_MouseUp(object sender, MouseEventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void MainFrm_MouseHover(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void MainFrm_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private List<RemoteDesktop> GetAllRemoteDestopObjBySerialNo(string serialNO)
        {
            List<RemoteDesktop> result = new List<RemoteDesktop>();

            if (remoteDesktop01.Tag.ToString() == serialNO)
            {
                result.Add(remoteDesktop01);
            }

            if (remoteDesktop02.Tag.ToString() == serialNO)
            {
                result.Add(remoteDesktop02);
            }

            if (remoteDesktop03.Tag.ToString() == serialNO)
            {
                result.Add(remoteDesktop03);
            }

            if (remoteDesktop04.Tag.ToString() == serialNO)
            {
                result.Add(remoteDesktop04);
            }

            if (remoteDesktop05.Tag.ToString() == serialNO)
            {
                result.Add(remoteDesktop05);
            }

            if (remoteDesktop06.Tag.ToString() == serialNO)
            {
                result.Add(remoteDesktop06);
            }

            return result;
        }

        private void timerProcessAlarm_Tick(object sender, EventArgs e)
        {
            try
            {
                timerProcessAlarm.Stop();

                string infos = alarmInfo.receiveBufferString.Dequeue();
                string[] splitResult = infos.Split('#');
                for (int i = 0; i < splitResult.Length; i++)
                {
                    string[] dataSplitResult = splitResult[i].Split(',');
                    if (dataSplitResult.Length < 4)
                    {
                        alarmRemeberString = splitResult[i];
                        continue;
                    }

                    var itemInfo = dataSplitResult[0].Split(':');
                    var redLampSingle = dataSplitResult[1].Split(':');

                    if (itemInfo.Length < 2 || redLampSingle.Length < 2 || redLampSingle[0].ToLower() != "readlampon")
                    {
                        continue;
                    }

                    var vncObj = clientInfos.Find(x => x.SerialNo == itemInfo[1].ToLower());
                    if (vncObj != null)
                    {
                        bool currentStatus = redLampSingle[1].ToLower() == "true" ? true : false;

                        var findResult = GetAllRemoteDestopObjBySerialNo(itemInfo[1].ToLower());

                        if (findResult.Find(remoteObj => remoteObj.IsConnected) == null)
                            continue;

                        if (vncObj.redLampState != currentStatus)
                        {
                            if (!currentStatus)
                            {
                                findResult.ForEach(x =>
                                {
                                    x.Parent.BackColor = Color.Transparent;
                                    x.Parent.Padding = new Padding(0, 0, 0, 0);
                                });
                            }
                            else
                            {
                                string infoSpeaker = vncObj.LineName + "��" + vncObj.name + "��������";
                                System.Threading.Tasks.Task.Run(() =>
                                {
                                    SpeakerOut(infoSpeaker);
                                });

                            }
                        }

                        vncObj.redLampState = currentStatus;
                        if (currentStatus)
                        {

                            Color bgColor = Color.Transparent;
                            if (vncObj.borderSetFlag)
                            {
                                bgColor = Color.Transparent;
                                vncObj.borderSetFlag = false;
                            }
                            else
                            {
                                bgColor = Color.Red;
                                vncObj.borderSetFlag = true;
                            }

                            findResult.ForEach(x =>
                            {
                                x.Parent.BackColor = bgColor;
                                x.Parent.Padding = new Padding(10, 10, 10, 10);
                            });


                        }
                    }

                }

            }
            catch (Exception Ex)
            {

            }
            finally
            {
                timerProcessAlarm.Start();
            }
        }


    }
}