﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VNCLayout
{
    public class clientInfo
    {
        /// <summary>
        /// 机器名称
        /// </summary>
        public string name = "";

        /// <summary>
        /// 机器的IP地址
        /// </summary>
        public string ipAddress = "127.0.0.1";

        /// <summary>
        /// 需要连接的VNC端口
        /// </summary>
        public int port = 5900;

        /// <summary>
        /// VNC密码
        /// </summary>
        public string vncPassword = "12321";

        /// <summary>
        /// 机器代码用于内部识别使用
        /// </summary>
        public string clientNo = "";

        /// <summary>
        /// 生产名称
        /// </summary>
        public string LineName = "";

        /// <summary>
        /// 机器在生产线系统内的编号
        /// </summary>
        public string SerialNo = "";

        /// <summary>
        /// 生灯报警信息（ON：报警中，OFF：正常）
        /// </summary>
        public bool redLampState = false;

        /// <summary>
        /// 是否已经设置过边框样式
        /// </summary>
        public bool borderSetFlag = false;

        /// <summary>
        /// 连接是否是手动断开（手动断开的将不再尝试重新连接）
        /// </summary>
        public bool isManualDisconnect = false;
    }
}
